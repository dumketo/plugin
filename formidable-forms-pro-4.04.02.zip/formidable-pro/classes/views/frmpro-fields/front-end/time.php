<?php
_deprecated_file( basename( __FILE__ ), '3.0', null, 'FrmFieldType::show_time_field' );
