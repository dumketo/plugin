<?php
//silence is golden.